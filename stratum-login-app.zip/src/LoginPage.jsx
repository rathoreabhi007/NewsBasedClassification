import { useState } from 'react'

export default function LoginPage() {
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')

  const handleLogin = () => {
    const credentials = { username: "admin", password: "123456" }
    if (username === credentials.username && password === credentials.password) {
      alert("Login successful!")
    } else {
      setError("Invalid username or password")
    }
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gray-100 dark:bg-gray-900 text-gray-800 dark:text-white transition">
      <div className="absolute top-4 left-4 flex items-center gap-4">
        <button>
          <svg width="24" height="24" fill="currentColor"><path d="M3 6h18M3 12h18M3 18h18"/></svg>
        </button>
        <button>
          <svg width="24" height="24" fill="currentColor"><path d="M12 3a9 9 0 000 18c0-3 3-3 3-9a3 3 0 10-6 0c0 6 3 6 3 9a9 9 0 000-18z"/></svg>
        </button>
      </div>
      <div className="absolute top-4 right-4">
        <span>English (US) ▾</span>
      </div>
      <h1 className="text-5xl font-bold mb-2">Stratum</h1>
      <p className="mb-8 text-center">Welcome to Stratum — your in-house reconciliation tool.</p>
      <div className="bg-slate-800 p-8 rounded-lg shadow-md w-full max-w-md">
        <h2 className="text-2xl font-semibold text-white mb-6 text-center">Login</h2>
        <input
          type="text"
          placeholder="Username"
          className="w-full mb-4 px-4 py-2 rounded border border-gray-500 bg-transparent text-white placeholder-gray-300"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
        />
        <input
          type="password"
          placeholder="Password"
          className="w-full mb-4 px-4 py-2 rounded border border-gray-500 bg-transparent text-white placeholder-gray-300"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
        {error && <p className="text-red-500 text-sm mb-2">{error}</p>}
        <button
          onClick={handleLogin}
          className="w-full py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded"
        >
          Login
        </button>
      </div>
    </div>
  )
}
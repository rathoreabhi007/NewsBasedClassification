import { useState } from 'react'
import LoginPage from './LoginPage'

export default function App() {
  return <LoginPage />
}